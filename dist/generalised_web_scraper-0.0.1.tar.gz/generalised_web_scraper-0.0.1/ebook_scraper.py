from WebScraper import WebScraper
from ElementSequence import ElementSequence
from Element import Element
from Selector import Selector

import os

# not the biggest fan of the critical=False for this. It is there because of the ensure_absensce in the elementSequence
username_textbox = Element(
    name="Username textbox",
    selectors="#Ecom_User_ID",
    send_values="s4003020",
    critical=False,
    timeout=1,
)
with open("C:\\Users\\sandr\\OneDrive\\Programming\\Selenium\\test.txt", "r") as f:
    output = f.read()
password_textbox = Element(
    name="Password textbox",
    selectors="#Ecom_Password",
    send_values=output,
    critical=False,
    timeout=1,
)
login_button = Element(
    name="Login button",
    selectors="#loginButton2",
    click=True,
    critical=False,
    timeout=1,
)
absent_login_button = Element(
    name="Ensure absence login button",
    selectors="#loginButton2",
    ensure_absence=True,
    timeout=1,
)


sign_in_sequence = ElementSequence(
    name="Sign In",
    elements=[username_textbox, password_textbox, login_button, absent_login_button],
    restart_on_fail=5,
)

accept_cookies = Element(
    name="Accept cookies",
    selectors=[
        '//*[@id="onetrust-accept-btn-handler"]',
        "/html/body/div[17]/div[2]/div/div[1]/div/div[2]/div/button[2]",
        '//*[@id="onetrust-reject-all-handler"]',
        "/html/body/div[17]/div[2]/div/div[1]/div/div[2]/div/button[3]",
    ],
    click=True,
    return_on_click=True,
    critical=False,
    timeout=0.1,
)


copy = Element(
    name="Copy button",
    selectors='//*[@id="toolCopy"]',
    click=True,
    critical=True,
    timeout=1,
)

copy_textbox = Element(
    name="Copy text box",
    selectors='//*[@id="copyContent"]',
    capture_attribute="innerHTML",
    critical=False,
    timeout=1,
)

done = Element(
    name="Done button",
    selectors='//*[@id="modalDone"]',
    click=True,
    critical=True,
    timeout=1,
)

next_page = Element(
    name="Next page button",
    selectors='//*[@id="tool-pager-next"]',
    click=True,
    return_on_click=True,
    critical=True,
    timeout=1,
)

grab_content_sequence = ElementSequence(
    name="Grab ebook content",
    # elements=[accept_cookies, copy, copy_textbox, done, next_page],
    elements=[accept_cookies, next_page],
    run_until_fail=True,
)


scraper = WebScraper(
    name="Proquest Ebook scraper",
    url="https://ebookcentral.proquest.com/lib/rmit/reader.action?docID=5903962",
    sign_in_url="https://rmit.instructure.com/",
    sequences=grab_content_sequence,
    sign_in_sequence=sign_in_sequence,
    root_path="C:\\Users\\sandr\\OneDrive\\Homework\\2024\\Software Testing",
    headless=False,
)

scraper.run()
