import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


class DriverProvider:

    def __new__(cls, name, headless=False, download_path=None):
        if not hasattr(cls, "instance"):
            cls.instance = super(DriverProvider, cls).__new__(cls)
        return cls.instance

    def __init__(self, name, headless=False, download_path=None):
        self.name = name

        if not download_path:
            download_path = os.getcwd()
        if not os.path.exists(download_path):
            raise Exception(f"Invalid download path '{download_path}'")
        self.download_path = os.path.join(
            os.getcwd() if not download_path else download_path, "WebScraper output"
        )
        # a bit of a stupid way to convert the scraper name to a valid file name
        # it might come back to bite me, as this conversion is not done everywhere
        self._current_scraper_path = os.path.join(download_path, self.name)
        if not os.path.exists(download_path):
            os.mkdir(download_path)
        if not os.path.exists(self._current_scraper_path):
            os.makedirs(self._current_scraper_path, exist_ok=True)

        options = Options()
        options.headless = headless

        # alternate option for setting download directory
        # prefs = {"download.default_directory": "C:\\Tutorial\\down"}
        # options.add_experimental_option("prefs", prefs)

        self.driver = webdriver.Chrome(options=options)

        # set initial download path
        self.driver.command_executor._commands["send_command"] = (
            "POST",
            "/session/$sessionId/chromium/send_command",
        )
        params = {
            "cmd": "Page.setDownloadBehavior",
            "params": {"behavior": "allow", "downloadPath": self.download_path},
        }
        self.driver.execute("send_command", params)
