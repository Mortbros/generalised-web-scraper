import requests

# url = "https://rmit.instructure.com/media_attachments/39363538/redirect?bitrate=180853"
url = "https://syd.cdn.nv.instructuremedia.com/originals/o-2Z3aUELwZYaKgiRXW8unau5edWt2fyTi/transcodings/t-2ZJWrf4hHt7C7xsPA9qaUBRbDwcvybXR.mp4?&Expires=1723677148&Signature=q8lEVhgqRktZpSojmEG3W7mnQfKLoT2sL7tjht3lSYHUS1yssxdX~~beNClAfzYtUxueQbzkBMWvTuoDXCMv0ihIPjDvq7VHmWSp-YQp40NigklZhjf6vS2oJQ~Qo0i5SeSM0I2zIVeq7ZY0ydd-NiFVvRhyhygouFOlDR1fJgd3~zV3gYxhlg~Qjvh39VAuu2rKPBghluQfHeJR2IShgB2WsYs6vAlLy~o~wVRai0hBZ579EZqeqnEU4TDJClCvjyjZKcXD9RWKqv0TcVizXTpT3cgOaGw6fZRHurjzxSiQQZ7cnXWpi4IsqGbRbOLJF~WS3sGOQ-KpnxU8dPWXEg__&Key-Pair-Id=APKAJLP4NHW7VFATZNDQ"


def download_file(url, filename):
    local_filename = filename
    # NOTE the stream=True parameter below
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(local_filename, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                # If you have chunk encoded response uncomment if
                # and set chunk_size parameter to None.
                # if chunk:
                f.write(chunk)
    return local_filename


# download_file(url, file_path)
file_path = "C:\\Users\\sandr\\OneDrive\\Homework\\2024\\Software Requirements Engineering\\Recordings\\035217_LTL01_2024-08-s1-full.mp4"

import whisper

model = whisper.load_model("medium", device="cuda")

result = model.transcribe(file_path)
print(result["text"])
with open("RECORDING TEXT.txt", "w") as f:
    f.write(str(result))
