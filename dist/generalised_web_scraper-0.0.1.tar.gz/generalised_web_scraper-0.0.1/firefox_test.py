import sys

print(sys.version)

from selenium import webdriver

driver = webdriver.Firefox()
# Get information about existing session
url = driver.command_executor._url  # "http://127.0.0.1:60622/hub"
session_id = driver.session_id


driver = webdriver.Remote(command_executor=url, desired_capabilities={})
driver.close()  # this prevents the dummy browser
driver.session_id = session_id

input()


# Dont close on program finish
options = Options()
options.add_experimental_option("detach", True)

driver = webdriver.Chrome(service=driver_service, options=options)
